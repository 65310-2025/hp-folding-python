#!/bin/bash

# Number of sequences to test
NUM=10

# Min and max length of HP sequences
MIN_LEN=2
MAX_LEN=10

echo "Testing for unique HP sequences using ./hp_folder..."

for ((i=0; i<$NUM; i++)); do
  # Generate random length between MIN_LEN and MAX_LEN
  LEN=$((RANDOM % (MAX_LEN - MIN_LEN + 1) + MIN_LEN))
  
  # Generate random HP sequence of that length
  SEQ=$(cat /dev/urandom | tr -dc 'HP' | fold -w $LEN | head -n 1)

  # Run the sequence through your folder
  OUTPUT=$(./hp_folder $SEQ 2>&1)

  # Check if it found only 1 optimal solution
  if echo "$OUTPUT" | grep -q "Found 1 optimal solutions"; then
    echo "✅ Unique: $SEQ" echo "$SEQ" >> unique.txt
  else
    echo "❌ Non-unique: $SEQ"
  fi
done

