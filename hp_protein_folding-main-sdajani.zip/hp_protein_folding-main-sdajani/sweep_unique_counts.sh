#!/bin/bash

echo "n unique_count" > unique_summary.txt

# Range of n values to test
for n in {4..10}; do
  ./test_all_sequences_n.sh $n >> unique_summary.txt
done

echo "✅ Finished testing. Here's the summary:"
column -t unique_summary.txt

# 🧪 Save as data file for gnuplot
cp unique_summary.txt unique_summary.dat

# 📈 Generate plot with gnuplot
gnuplot -persist <<EOF
set terminal png size 800,600
set output 'unique_vs_n.png'
set title "Unique HP Folds vs Sequence Length (n)"
set xlabel "Sequence Length (n)"
set ylabel "Number of Unique Sequences"
set grid
set style data linespoints
plot 'unique_summary.dat' using 1:2 title "Unique Sequences" lt rgb "blue" lw 2 pt 7
EOF

echo "✅ Plot saved as unique_vs_n.png"

