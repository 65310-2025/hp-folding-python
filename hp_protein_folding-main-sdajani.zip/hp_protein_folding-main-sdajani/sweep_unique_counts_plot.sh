#!/bin/bash

echo "n unique_count" > unique_summary.txt

# Sweep over range of n values
for n in {4..12}; do
  ./test_all_sequences_n.sh $n >> unique_summary.txt
done

echo "✅ Finished testing. Here's the summary:"
column -t unique_summary.txt

# Prepare probability data
echo "n probability" > unique_probability.dat
tail -n +2 unique_summary.txt | while read n count; do
  total=$((2**n))
  prob=$(awk "BEGIN {printf \"%.6f\", $count/$total}")
  echo "$n $prob" >> unique_probability.dat
done

# Plot 1: Raw counts
gnuplot -persist <<EOF
set terminal png size 800,600
set output 'unique_vs_n.png'
set title "Unique HP Folds vs Sequence Length (n)"
set xlabel "Sequence Length (n)"
set ylabel "Number of Unique Sequences"
set grid
set style data linespoints
plot 'unique_summary.txt' using 1:2 title "Unique Count" lt rgb "blue" lw 2 pt 7
EOF

# Plot 2: Probability plot
gnuplot -persist <<EOF
set terminal png size 800,600
set output 'unique_probability.png'
set title "Probability of Unique Fold vs Sequence Length (n)"
set xlabel "Sequence Length (n)"
set ylabel "Probability"
set grid
set yrange [0:1.05]
set style data linespoints
plot 'unique_probability.dat' using 1:2 title "Probability of Unique Fold" lt rgb "green" lw 2 pt 7
EOF

echo "✅ Plots saved: unique_vs_n.png and unique_probability.png"

