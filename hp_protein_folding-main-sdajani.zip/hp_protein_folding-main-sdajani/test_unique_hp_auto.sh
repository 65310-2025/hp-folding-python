#!/bin/bash

# Number of sequences to test
NUM=100

# Min and max length of HP sequences
MIN_LEN=2
MAX_LEN=10

echo "Testing for unique HP sequences using ./hp_folder..."

# Clear previous output file
> unique.txt

for ((i=0; i<$NUM; i++)); do
  # Generate random length between MIN_LEN and MAX_LEN
  LEN=$((RANDOM % (MAX_LEN - MIN_LEN + 1) + MIN_LEN))

  # ✅ Fixed: Generate random HP sequence safely
  SEQ=$(LC_CTYPE=C tr -dc 'HP' < /dev/urandom | head -c $LEN)

  # Skip empty results (edge case)
  if [[ -z "$SEQ" ]]; then
    continue
  fi

  # Run the sequence
  OUTPUT=$(./hp_folder "$SEQ" 2>&1)

  # Check uniqueness
  if echo "$OUTPUT" | grep -q "Found 1 optimal solutions"; then
    echo "✅ Unique: $SEQ"
    echo "$SEQ" >> unique.txt
  else
    echo "❌ Non-unique: $SEQ"
  fi
done

