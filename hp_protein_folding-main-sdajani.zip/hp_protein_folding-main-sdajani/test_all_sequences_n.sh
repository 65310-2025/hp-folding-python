#!/bin/bash

# Get length N from argument
N=$1

# Output folders
mkdir -p all_structures_n${N}
> all_unique_n${N}.txt

TOTAL=$((1 << N))
echo "Testing all $TOTAL sequences of length $N..."

for ((i=0; i<TOTAL; i++)); do
  BIN=$(printf "%0${N}d" "$(echo "obase=2; $i" | bc)")
  SEQ=$(echo "$BIN" | tr '01' 'HP')

  if [[ -z "$SEQ" || ${#SEQ} -ne $N ]]; then
    continue
  fi

  OUTPUT=$(./hp_folder "$SEQ" 2>&1)

  if echo "$OUTPUT" | grep -q "Found 1 optimal solutions"; then
    echo "$SEQ" >> all_unique_n${N}.txt
    STRUCT=$(echo "$OUTPUT" | awk '/-----/{f=1} f; /-----/{if (++count==2) exit}')
    echo "$STRUCT" > "all_structures_n${N}/${SEQ}.txt"
  fi
done

# Print number of unique sequences
echo -n "$N "  # no newline
wc -l < all_unique_n${N}.txt  # count lines

