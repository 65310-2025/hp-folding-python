#!/bin/bash

# Number of sequences to test
NUM=10

# Min and max length of HP sequences
MIN_LEN=2
MAX_LEN=10

echo "Testing for unique HP sequences using ./hp_folder..."

# Clear previous output files
> unique.txt
mkdir -p unique_structures

for ((i=0; i<$NUM; i++)); do
  LEN=$((RANDOM % (MAX_LEN - MIN_LEN + 1) + MIN_LEN))
  SEQ=$(LC_CTYPE=C tr -dc 'HP' < /dev/urandom | head -c $LEN)

  if [[ -z "$SEQ" ]]; then
    continue
  fi

  OUTPUT=$(./hp_folder "$SEQ" 2>&1)

  if echo "$OUTPUT" | grep -q "Found 1 optimal solutions"; then
    echo "✅ Unique: $SEQ"

    # Save sequence to list
    echo "$SEQ" >> unique.txt

    # Extract config diagram from output (everything between first "-----" blocks)
    STRUCT=$(echo "$OUTPUT" | awk '/-----/{f=1} f; /-----/{if (++count==2) exit}')

    # Show it inline
    echo "$STRUCT"

    # Save it to a file named after the sequence
    echo "$STRUCT" > "unique_structures/${SEQ}.txt"
  else
    echo "❌ Non-unique: $SEQ"
  fi
done

